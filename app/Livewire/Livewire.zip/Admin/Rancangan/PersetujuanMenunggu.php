<?php

namespace App\Livewire\Admin\Rancangan;

use Livewire\Component;
use Livewire\WithPagination;
use Livewire\WithoutUrlPagination;
use App\Models\RancanganProdukHukum;
use App\Models\User;
use Illuminate\Support\Carbon;
use App\Notifications\PersetujuanRancanganNotification;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\log;


class PersetujuanMenunggu extends Component
{
    use WithPagination, WithoutUrlPagination;

    public $search = '';
    public $perPage = 5; // Default jumlah data per halaman

    public $selectedRancangan;

    public $catatan;
    public $statusBerkas;

    protected $rules = [
        'statusBerkas' => 'required|in:Disetujui,Ditolak',
        'catatan' => 'required|string|min:5',
    ];

    protected $messages = [
        'statusBerkas.required' => 'Status harus dipilih.',
        'catatan.required' => 'Catatan wajib diisi.',
        'catatan.min' => 'Catatan minimal 5 karakter.',
        'catatan.max' => 'Catatan maksimal 255 karakter.',
    ];

    public function updatedPerPage()
    {
        $this->resetPage(); // Reset pagination saat jumlah per halaman berubah
    }

    public function openModal($id)
    {
        $this->selectedRancangan = RancanganProdukHukum::with(['user', 'perangkatDaerah'])->find($id);
        if (!$this->selectedRancangan || Gate::denies('view', $this->selectedRancangan)) {
            abort(403, 'Unauthorized access');
        }
        $this->catatan = $this->selectedRancangan->catatan_berkas ?? '';
        $this->statusBerkas = $this->selectedRancangan->status_berkas ?? '';
        $this->dispatch('openModal', 'modalPersetujuan');
    }

    public function updateStatus()
    {
        $this->validate();

        if ($this->selectedRancangan) {
            $this->selectedRancangan->status_berkas = $this->statusBerkas;
            $this->selectedRancangan->catatan_berkas = $this->catatan;

            // Set tanggal_berkas_disetujui jika status disetujui
            if ($this->statusBerkas === 'Disetujui') {
                $this->selectedRancangan->tanggal_berkas_disetujui = Carbon::now();

                // Update status_revisi di tabel Revisi menjadi 'Menunggu Peneliti'
                $revisi = $this->selectedRancangan->revisi()->first(); // Ambil revisi terkait
                if ($revisi) {
                    $revisi->update([
                        'status_revisi' => 'Menunggu Peneliti',
                    ]);
                }

                // Kirim notifikasi ke verifikator
                $verifikator = User::role('Verifikator')->get(); // Ambil semua user dengan role Verifikator
                Notification::send(
                    $verifikator, // Semua verifikator
                    new PersetujuanRancanganNotification([
                        'title' => "Berkas Rancangan No. {$this->selectedRancangan->no_rancangan} Disetujui! ",
                        'message' => " Berkas Rancangan dengan nomor *{$this->selectedRancangan->no_rancangan}* telah berhasil disetujui!  Harap segera *memilih peneliti* untuk melanjutkan proses berikutnya. ",
                        'slug' => $this->selectedRancangan->slug, // Slug untuk modal detail
                        'type' => 'pilih_peneliti', // Tipe notifikasi untuk verifikator
                    ])
                );
            } else {
                $this->selectedRancangan->tanggal_berkas_disetujui = null; // Reset jika bukan "Disetujui"
            }

            $this->selectedRancangan->save();

            // Kirim notifikasi ke user
            Notification::send(
                $this->selectedRancangan->user, // User yang mengajukan rancangan
                new PersetujuanRancanganNotification([
                    'title' => $this->statusBerkas === 'Disetujui'
                        ? " Berkas Rancangan No. {$this->selectedRancangan->no_rancangan} Disetujui!"
                        : " Berkas Rancangan No. {$this->selectedRancangan->no_rancangan} Ditolak!",

                    'message' => $this->statusBerkas === 'Disetujui'
                        ? " Selamat! Berkas Rancangan Anda telah *disetujui* . Proses selanjutnya adalah *penugasan Peneliti* . Mohon menunggu pemilihan peneliti."
                        : " Mohon maaf, Berkas Rancangan Anda *ditolak* . Silakan periksa *catatan revisi* 📝 dan lakukan perbaikan sebelum mengajukan ulang. ",

                    'slug' => $this->selectedRancangan->slug, // Slug untuk modal detail
                    'type' => $this->statusBerkas === 'Disetujui' ? 'persetujuan_diterima' : 'persetujuan_ditolak', // Tentukan tipe notifikasi
                ])
            );

            // Emit notifikasi sukses ke pengguna
            $this->dispatch('refreshNotifications');
            // reset
            $this->resetForm();

            $this->dispatch('closeModal', 'modalPersetujuan');

            $this->dispatch('swal:toast', [
                'type' => 'success',
                'message' => 'Status rancangan berhasil diperbarui!',
            ]);
        }
    }

    public function resetForm()
    { // Atur ulang semua properti ke nilai default
        $this->selectedRancangan = null;

        $this->resetErrorBag(); // Reset error validasi
        $this->resetValidation(); // Reset tampilan error validasi
    }

    public function jalankanPrediksi($id)
    {
        $item = RancanganProdukHukum::find($id);
        if (!$item) return;

        $indikator = [
            'nota_dinas_ada' => $item->nota_dinas_pd ? 1 : 0,
            'rancangan_ada' => $item->rancangan ? 1 : 0,
            'matrik_ada' => $item->matrik ? 1 : 0,
        ];

        $request = Http::asMultipart();

        if ($item->nota_dinas_pd && Storage::exists($item->nota_dinas_pd)) {
            $request = $request->attach('nota_dinas_file', Storage::get($item->nota_dinas_pd), basename($item->nota_dinas_pd));
        }
        if ($item->rancangan && Storage::exists($item->rancangan)) {
            $request = $request->attach('rancangan_file', Storage::get($item->rancangan), basename($item->rancangan));
        }
        if ($item->matrik && Storage::exists($item->matrik)) {
            $request = $request->attach('matrik_file', Storage::get($item->matrik), basename($item->matrik));
        }

        try {
            $response = $request->post('http://localhost:5000/extract');
            if ($response->successful()) {
                $indikatorIsi = $response->json();
                $fitur = array_merge($indikator, $indikatorIsi);

                // ✨ Deteksi indikator tidak lengkap
                $tidakLengkap = [];
                foreach ($fitur as $key => $value) {
                    if ($value == 0) $tidakLengkap[] = $key;
                }

                // Mapping teknis → label manusiawi (optional)
                $map = [
                    'nota_dinas_tertanggal' => 'Nota Dinas belum tertanggal',
                    'nota_dinas_memiliki_nomor' => 'Nota Dinas tidak memiliki nomor',
                    'nota_dinas_memiliki_perihal' => 'Nota Dinas tidak memiliki perihal',
                    'nota_dinas_ada_pengantar' => 'Tidak ada pengantar dalam Nota Dinas',
                    'nota_dinas_ada_dasar_hukum' => 'Tidak ada dasar hukum dalam Nota Dinas',
                    'nota_dinas_ada_penutup' => 'Penutup Nota Dinas belum tersedia',
                    'nota_dinas_tertandatangan' => 'Nota Dinas belum ditandatangani',
                    'rancangan_judul_dokumen' => 'Rancangan belum memiliki judul',
                    'rancangan_memiliki_tentang' => 'Rancangan tidak memiliki bagian tentang',
                    'rancangan_memiliki_mengingat' => 'Rancangan tidak memiliki mengingat',
                    'rancangan_memiliki_menimbang' => 'Rancangan tidak memiliki menimbang',
                    'rancangan_memiliki_dasar_hukum' => 'Dasar hukum Rancangan belum lengkap',
                    'rancangan_memiliki_pasal' => 'Pasal dalam Rancangan belum ditemukan',
                    'rancangan_memiliki_penutup' => 'Penutup Rancangan belum tersedia',
                    'rancangan_tertandatangan' => 'Rancangan belum ditandatangani',
                    'matrik_memiliki_judul' => 'Judul Matrik belum tersedia',
                    'matrik_memiliki_konsideran' => 'Konsideran Matrik belum ditemukan',
                    'matrik_memiliki_dasar_hukum' => 'Dasar hukum Matrik belum tersedia',
                    'matrik_memiliki_diktum' => 'Diktum dalam Matrik belum tersedia',
                    'matrik_memiliki_batang_tubuh' => 'Batang tubuh Matrik belum ada',
                    'matrik_memiliki_lampiran' => 'Lampiran Matrik belum ada',
                    'matrik_memiliki_keterangan' => 'Keterangan tambahan Matrik kosong',
                ];

                $catatan = collect($tidakLengkap)
                    ->map(fn($k) => $map[$k] ?? $k)
                    ->implode('; ');

                // Kirim ke model ML
                $prediksi = Http::post('http://localhost:5000/predict', $fitur);
                $hasil = $prediksi->json()['result'] ?? 'Tidak Lengkap';

                $item->hasil_prediksi_kelengkapan = $hasil;
                $item->catatan_berkas = $hasil === 'Lengkap' ? null : $catatan;
                $item->save();

                $this->dispatch('swal:toast', [
                    'type' => 'success',
                    'message' => "Prediksi berhasil: {$hasil}"
                ]);
            }
        } catch (\Exception $e) {
            Log::error("Gagal prediksi: " . $e->getMessage());
            $this->dispatch('swal:toast', [
                'type' => 'error',
                'message' => "Gagal menghubungi API prediksi."
            ]);
        }
    }


    public function render()
    {

        $rancanganMenunggu = RancanganProdukHukum::with(['user', 'perangkatDaerah'])
            ->whereIn('status_berkas', ['Menunggu Persetujuan'])
            ->where('status_rancangan', 'Dalam Proses')
            ->where(function ($query) {
                $query->where('no_rancangan', 'like', "%{$this->search}%")
                    ->orWhere('tentang', 'like', "%{$this->search}%");
            })
            ->orderBy('tanggal_pengajuan', 'desc') // Urutkan berdasarkan tangal pengakuan
            ->paginate($this->perPage);



        return view('livewire.admin.rancangan.persetujuan-menunggu', compact('rancanganMenunggu'));
    }
}
